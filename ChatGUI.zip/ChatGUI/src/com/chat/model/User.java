package com.chat.model;

/**
 * �û�ʵ��
 * @author q1565
 *
 */

public class User {
	private int id;
	private String username;
	private String password;
}

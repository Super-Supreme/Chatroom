package com.chat.gui;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DbUtil {
	private final String dbUrl ="jdbc:mysql://localhost:3306/db_chatapp";	
	private String dbusername="root";	//�û���
	private String dbpassword="root";	//����
	private String jdbcName="com.mysql.cj.jdbc.Driver";	//��������
	
	public Connection getCon() {
		Connection con=null;
		try {
			Class.forName(jdbcName);
			con = DriverManager.getConnection(dbUrl, dbusername, dbpassword);
			return con;
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		return con;
	}
	
	public void closeCon(Connection con) {
		if(con!=null) {
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	public static void main(String[] args) {
		DbUtil dbutil = new DbUtil();
		dbutil.getCon();
		System.out.println();
	}
}

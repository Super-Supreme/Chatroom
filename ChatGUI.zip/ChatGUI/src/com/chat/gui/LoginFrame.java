package com.chat.gui;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class LoginFrame extends JFrame {

	private JPanel contentPane;
	private JTextField textField;
	private JTextField textField_1;
	private JTextField textField_2;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LoginFrame frame = new LoginFrame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public LoginFrame() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		setLocationRelativeTo(null);
		setTitle("                                   ��¼������");
		contentPane.setLayout(null);
		
		JLabel lblip = new JLabel("\u670D\u52A1\u5668IP\uFF1A");
		lblip.setBounds(55, 53, 80, 15);
		lblip.setHorizontalAlignment(SwingConstants.RIGHT);
		contentPane.add(lblip);
		
		JLabel label = new JLabel("\u670D\u52A1\u5668\u7AEF\u53E3\uFF1A");
		label.setBounds(55, 101, 80, 15);
		label.setHorizontalAlignment(SwingConstants.RIGHT);
		contentPane.add(label);
		
		textField = new JTextField();
		textField.setBounds(146, 50, 197, 21);
		contentPane.add(textField);
		textField.setColumns(10);
		
		textField_1 = new JTextField();
		textField_1.setBounds(145, 98, 132, 21);
		contentPane.add(textField_1);
		textField_1.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("\u6635\u79F0\uFF1A");
		lblNewLabel.setBounds(80, 146, 54, 15);
		lblNewLabel.setHorizontalAlignment(SwingConstants.RIGHT);
		contentPane.add(lblNewLabel);
		
		textField_2 = new JTextField();
		textField_2.setBounds(146, 146, 131, 21);
		contentPane.add(textField_2);
		textField_2.setColumns(10);
		
		JButton button = new JButton("\u53D6    \u6D88");
		button.setBounds(55, 205, 93, 23);
		contentPane.add(button);
		
		//��¼��ť
		JButton button_1 = new JButton("\u767B     \u5F55");
		button_1.setBounds(262, 205, 93, 23);
		button_1.addActionListener(new ActionListener() {
			//�������ĵ���¼�
			public void actionPerformed(ActionEvent e) {
				//�����û��б�����--->�����ⲿ�෽��
				toUserListFrame();
			}
		});
		contentPane.add(button_1);
	}

	protected void toUserListFrame() {
		//�������Լ�
		dispose();
		
		//��ʾ�û��б�����
		UserListFrame userlistframe = new UserListFrame();
		userlistframe.setVisible(true);
	}
}

package com.chat.view;
public class ChatUtils {
	public static String getText(String row1,String row2){
		return "<html><body>" + row1 + "<br/><br/>" + row2 + "<br/>&nbsp;</body></html>";
	}
	
	public static String makeMsg(int location,String msg){
		//msg��ʽ����ǰ�û���@��ǰ�û�ip@msg@�Է��û���@�Է�ip@����ʱ��
		String[] msgArray = msg.split("@");
		String fromUser = msgArray[0];
		String fromIp = msgArray[1];
		String msgContent = msgArray[2];
		String toUser = msgArray[3];
		String toIp = msgArray[4];
		String time = msgArray[5];
		
		StringBuilder bld = new StringBuilder();
		String ct = location == 1 ? "left":"right";
		String color = location == 1 ? "red" : "blue";
		bld.append("<p align = '" + ct + "'><font color = 'blue'><b>��").append(fromUser).append("��   ")
		.append(time).append("</b></font><br>")
		.append("  <font color = '" + color + "'>").append(msgContent)
		.append("</font><br></p>");
		
		return bld.toString();
	}
}
